# Simulador de capacitores → APK

1. Crea un repositorio nuevo en github.com (puede ser privado).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
   Con git:  git init && git add . && git commit -m "app" && git branch -M main && git remote add origin <URL> && git push -u origin main
3. En GitHub abre la pestaña **Actions**. Se ejecuta "Construir APK" (o pulsa *Run workflow*). Tarda ~5 min.
4. Entra a la ejecución terminada, baja a **Artifacts** y descarga `simulador-capacitores-apk` (un zip con `app-debug.apk`).
5. Pasa el APK al celular y ábrelo (permite "instalar apps de origen desconocido").

Para actualizar la app: reemplaza `www/index.html` y vuelve a subir; se genera un APK nuevo.
En el APK se ocultan Exportar/Importar e Imprimir (no funcionan dentro de la app); el autoguardado sí funciona.
